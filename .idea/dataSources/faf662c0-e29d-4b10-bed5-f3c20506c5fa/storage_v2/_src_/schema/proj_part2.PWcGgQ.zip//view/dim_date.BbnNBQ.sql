create definer = root@localhost view dim_date as
select distinct `a`.`date_timestamp`             AS `date_timestamp`,
                dayofmonth(`a`.`date_timestamp`) AS `DAY(a.date_timestamp)`,
                month(`a`.`date_timestamp`)      AS `MONTH(a.date_timestamp)`,
                year(`a`.`date_timestamp`)       AS `YEAR(a.date_timestamp)`
from `proj_part2`.`appointment` `a`;

