create definer = root@localhost view dim_client as
select `proj_part2`.`client`.`client_VAT`    AS `client_VAT`,
       `proj_part2`.`client`.`client_gender` AS `client_gender`,
       `proj_part2`.`client`.`client_age`    AS `client_age`
from `proj_part2`.`client`;

