create definer = root@localhost view dim_location_client as
select distinct `proj_part2`.`client`.`client_zip`  AS `client_zip`,
                `proj_part2`.`client`.`client_city` AS `client_city`
from `proj_part2`.`client`;

