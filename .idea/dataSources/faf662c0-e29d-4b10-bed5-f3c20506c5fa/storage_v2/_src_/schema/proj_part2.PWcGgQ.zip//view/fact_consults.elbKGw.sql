create definer = root@localhost view fact_consults as
select `dc`.`client_VAT`                                                     AS `VAT`,
       `dd`.`date_timestamp`                                                 AS `date`,
       `dlc`.`client_zip`                                                    AS `zip`,
       count(distinct `pic`.`procedure_name_`)                               AS `num_procedures`,
       count(distinct `p`.`medication_name`, `p`.`medication_lab`, `p`.`ID`) AS `num_medications`,
       count(distinct `cd`.`ID`)                                             AS `num_diagnostic_codes`
from `proj_part2`.`dim_date` `dd`
         join `proj_part2`.`dim_client` `dc`
         join `proj_part2`.`dim_location_client` `dlc`
         join `proj_part2`.`client` `clt`
         join ((((`proj_part2`.`appointment` `a` join `proj_part2`.`consultation` `c` on (
        `a`.`VAT_doctor` = `c`.`VAT_doctor` and
        `a`.`date_timestamp` = `c`.`date_timestamp`)) left join `proj_part2`.`consultation_diagnostic` `cd` on (
        `a`.`VAT_doctor` = `cd`.`VAT_doctor` and
        `a`.`date_timestamp` = `cd`.`date_timestamp`)) left join `proj_part2`.`prescription` `p` on (
        `a`.`VAT_doctor` = `p`.`VAT_doctor` and
        `a`.`date_timestamp` = `p`.`date_timestamp`)) left join `proj_part2`.`procedure_in_consultation` `pic` on (
        `a`.`VAT_doctor` = `pic`.`VAT_doctor` and `a`.`date_timestamp` = `pic`.`date_timestamp`))
where `dc`.`client_VAT` = `a`.`VAT_client`
  and `clt`.`client_zip` = `dlc`.`client_zip`
  and `dd`.`date_timestamp` = `a`.`date_timestamp`
group by `dc`.`client_VAT`, `dd`.`date_timestamp`;

